export const dc = {
    fate_chips: {
        
    }
};